package com.ufc.diversos.dto;

import lombok.Data;

@Data
public class LoginDTO {
    private String email;
    private String senha;
}
