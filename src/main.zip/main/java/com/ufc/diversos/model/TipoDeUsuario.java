package com.ufc.diversos.model;

public enum TipoDeUsuario {
    USUARIO,
    ADMINISTRADOR,
    MODERADOR
}
