package com.ufc.diversos.model;

public enum StatusUsuario {
    ATIVO,
    INATIVO,
    BLOQUEADO,
    SUSPENSO
}
